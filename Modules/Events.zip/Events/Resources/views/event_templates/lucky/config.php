<?php

return [
    'is_premium' => true, // false or true for premium template
];