<?php

return [
    'is_premium' => false, // false or true for premium template
];