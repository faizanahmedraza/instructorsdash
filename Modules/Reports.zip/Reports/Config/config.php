<?php

return [
    'name' => 'Reports',
    'menu' => [
        'siderbar_position' => 1,
    ],
];
