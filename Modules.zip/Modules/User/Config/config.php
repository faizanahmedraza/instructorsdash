<?php

return [
    'name' => 'User',
    'menu' => [
        'siderbar_admin_position' => 10,
        'header_top_left' => 99,
    ],
    'USER_EMAIL_CONTENT' => '<p>Hi, <strong>%name%</strong><br/>%body%<br/><br/>Thanks</p>',
];
