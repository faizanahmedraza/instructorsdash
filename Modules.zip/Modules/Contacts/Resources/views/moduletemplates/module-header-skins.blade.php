<li class="nav-item">
    <a class="nav-link" href="{{ route('contacts') }}">
        @lang('Contacts')
    </a>
</li>