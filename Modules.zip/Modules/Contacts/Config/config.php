<?php

return [
    'name' => 'Contacts',
    'menu' => [
        'header_skins_position' => 4,
        'siderbar_admin_position' => 5,
    ],
];
