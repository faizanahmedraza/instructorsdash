<li class="nav-item">
    <a class="nav-link" href="{{ route('all-events.index') }}">
        @lang('Events')
    </a>
</li>