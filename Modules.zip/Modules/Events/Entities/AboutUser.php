<?php

namespace Modules\Events\Entities;

use Illuminate\Database\Eloquent\Model;

class AboutUser extends Model
{
    protected $table = "about_users";
    protected $guarded = [];
}
