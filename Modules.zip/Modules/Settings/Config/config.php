<?php

return [
    'name' => 'Settings',
    'menu' => [
        'siderbar_admin_position' => 1,
    ],
];
