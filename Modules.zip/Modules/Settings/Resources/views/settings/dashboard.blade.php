@extends('core::layouts.app')
@section('title', __('Dashboard'))
@section('content')
{{-- Example Dashboard --}}
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">@lang('Admin Dashboard')</h1>
</div>



{{-- End Admin Dashboard --}}

@stop