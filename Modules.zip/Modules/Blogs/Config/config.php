<?php

return [
    'name' => 'Blogs',
    'menu' => [
        'siderbar_admin_position' => 4,
        'header_skins_position' => 3,
    ],
];
