<li class="nav-item">
    <a class="nav-link" href="{{ route('blogs') }}">
        @lang('Blogs')
    </a>
</li>