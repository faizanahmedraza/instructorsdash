<ul class="navbar-nav sidebar background-light accordion d-none d-md-block" id="accordionSidebarAdmin">
    <div class="sidebar-heading pt-3">
        @lang('Admin Menu')  
    </div>
    {!! menuAdminSettingSiderbar() !!}
</ul>