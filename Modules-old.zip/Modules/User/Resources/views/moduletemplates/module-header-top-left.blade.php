@impersonating
<li class="nav-item">
  <a class="nav-link" href="{{ route('users.leaveimpersonate') }}">
    <i class="fas fa-sign-out-alt fa-lg"></i>
    <span class="d-none d-sm-inline-block ml-2">@lang('Logout Impersonate')</span>
  </a>
</li>
@endImpersonating